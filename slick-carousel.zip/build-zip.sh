#! /bin/bash
zip -r --exclude=*.git* slick-carousel.zip .
